#ifndef _ARM_CONST_H
#define _ARM_CONST_H

#define DEFAULT_HZ        1000

#endif /* #ifndef _ARM_CONST_H */
