/*
server/ip/gen/oneCsum.h
*/

#ifndef __SERVER__IP__GEN__ONECSUM_H__
#define __SERVER__IP__GEN__ONECSUM_H__

u16_t oneC_sum( u16_t prev, void *data, size_t data_len );

#endif /* __SERVER__IP__GEN__ONECSUM_H__ */
