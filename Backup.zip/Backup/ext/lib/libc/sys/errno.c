/*	$NetBSD: errno.c,v 1.5 2005/06/12 05:21:27 lukem Exp $	*/

#include <sys/cdefs.h>
#if defined(LIBC_SCCS) && !defined(lint)
__RCSID("$NetBSD: errno.c,v 1.5 2005/06/12 05:21:27 lukem Exp $");
#endif /* LIBC_SCCS and not lint */

int errno;
