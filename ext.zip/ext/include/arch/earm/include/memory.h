/* Physical memory layout */

#ifndef _ARM_MEMORY_H
#define _ARM_MEMORY_H

/* omap */
#define PHYS_MEM_BEGIN 0x80000000
#define PHYS_MEM_END 0xbfffffff

#endif /* _ARM_MEMORY_H */
