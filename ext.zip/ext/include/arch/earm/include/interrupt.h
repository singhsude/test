/* Interrupt numbers and hardware vectors. */

#ifndef _INTERRUPT_H
#define _INTERRUPT_H

#define NR_IRQ_VECTORS    125

#endif /* _INTERRUPT_H */
