/*
 * Dummy file for Minix old includes compatibility.
 */
#include <sys/cdefs.h>
#include <sys/endian.h>
